#include "SistemaParticulas.h"
#include <iostream>


SistemaParticulas::SistemaParticulas(float c, int LT, int vel, int nP, int S, ParticleForceRegistry* fR) {
	cadence = c;

	forceRegistry = fR;

	lifeTime = LT;
	speed = vel;
	numParticulas = nP;
	size = S;

	actTime = 0;

	srand(time(NULL));
}

SistemaParticulas::~SistemaParticulas() {
	for (auto a : particulas) delete a;
}

void SistemaParticulas::instantiateParticles() {
	float ang = 0;
	for (int i = 0; i < numParticulas; i++) {
		float x = cos(ang);
		float z = sin(ang);

		float r = (rand() % 9 + 1); r /= 10;
		float g = (rand() % 9 + 1); g /= 10;
		float b = (rand() % 9 + 1); b /= 10;

		auto p = new Particula(Vector3(0, -350, 0), Vector3(speed * x, 0, speed * z), Vector3(0, 0, 0), { r, g, b, 1 }, lifeTime, size, 5);

		ParticleGravity* gravity = new ParticleGravity(Vector3(0, 9.8, 0));
		forceRegistry->add(p, gravity);

		particulas.push_back(p);

		ang += (360.0f / numParticulas);
	}
}

void SistemaParticulas::update(float t) {

	auto p = particulas.begin();
	while (p != particulas.end()) {

		if ((*p)->alive()) {
			(*p)->update(t);
			p++;
		}
		else {
			forceRegistry->deleteParticleRegistry(*p);
			delete* p;
			p = particulas.erase(p);
		}
	}

	actTime -= t;
	if (actTime < 0) {
		instantiateParticles();
		actTime = cadence;
	}
}
