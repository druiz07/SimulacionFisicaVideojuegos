#include "FireworkSystem.h"
#include <iostream>

FireworkSystem::FireworkSystem(ParticleForceRegistry* fR, Vector3 posIni, Vector4 color) {
	forceRegistry = fR;

	//Informaci�n sobre cada tipo de particula
	info = vector<typeInfo>(3);

	info[TYPE0] = {
		Vector3(0, 150 ,0),									//Vel
		Vector3(0, 0, 0),									//Acc
		color,								//Color
		100,												//Size
		0.999,												//Damp
		5,												//MaxLifeTime
		4,												//MinLifeTime
		type::TYPE0,										//Tipo
		100,												//Particulas al explotar
		100,  												//Vel min
		200,      											//Vel max
		type::TYPE1,										//Tipo de particula que genera al explotar
		physx::PxTransform(posIni.x, posIni.y, posIni.z)	//Posicion de la particula inicial
	};

	info[TYPE1] = {
		Vector3(0, 0, 0),
		Vector3(0, 0, 0),
		color,
		80,
		0.999,
		0.7,
		0.3,
		type::TYPE1,
		5,
		100,
		200,
		type::TYPE2,
		physx::PxTransform(0,0,0)
	};

	info[TYPE2] = {
		Vector3(0, 0, 0),
		Vector3(0, 0, 0),
		color,
		60,
		0.999,
		1,
		1.3,
		type::TYPE2,
		0,
		100,
		200,
		type::NONE_TYPE,
		physx::PxTransform(0,0,0)
	};
}

FireworkSystem::~FireworkSystem() {
	for (auto a : fireworks) delete a;
}

void FireworkSystem::update(float t) {
	auto p = fireworks.begin();
	while (p != fireworks.end()) {

		if ((*p)->alive()) {
			(*p)->update(t);
			p++;
		}
		else {
			forceRegistry->deleteParticleRegistry(*p);
			(*p)->explode(this);
			delete* p;
			p = fireworks.erase(p);
		}
	}
}

void FireworkSystem::instantiateInitFirework() {
	auto type = info[TYPE0];
	createFirework(type, type.pos.p, type.vel);
}

void FireworkSystem::instantiateFirework(type t, Vector3 pos, Vector3 parentVel) {
	auto type = info[t];

	//Velocidad aleatoria en todas las direcciones mas velocidad del padre
	Vector3 vel;
	vel.x = (rand() % type.velMax) - type.velMin + parentVel.x;
	vel.y = (rand() % type.velMax) - type.velMin + parentVel.y;
	vel.z = (rand() % type.velMax) - type.velMin + parentVel.z;

	createFirework(type, pos, vel);
}


void FireworkSystem::createFirework(const typeInfo& type, Vector3 pos, Vector3 vel) {
	float lifeTime = type.minLifeTime + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (type.maxLifeTime - type.minLifeTime))); //Tiempo de vida aleatorio

	Firework* f = new Firework(pos, vel, type.acc, type.color, lifeTime, type.size, type.pType, type.numFireworksToInstantiate);

	ParticleGravity* gravity = new ParticleGravity(Vector3(0, -15, 0));

	forceRegistry->add(f, gravity);

	fireworks.push_back(f);
}