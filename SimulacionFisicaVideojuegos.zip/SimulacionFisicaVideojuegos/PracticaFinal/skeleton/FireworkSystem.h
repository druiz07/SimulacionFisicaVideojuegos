#pragma once
#include "RenderUtils.hpp"
#include "core.hpp"
#include "Firework.h"
#include <vector>
#include <list>
#include "ParticleForceRegistry.h"
#include "ParticleGravity.h"
#include "ParticleWind.h"
#include "ParticleExplosion.h"
#include "ParticleDrag.h"
#include "Explosion.h"
#include "GeneradorSimple.hpp"

#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

using namespace std;

struct typeInfo {
	Vector3 vel;
	Vector3 acc;
	Vector4 color;

	float size;
	double damp;
	float maxLifeTime;
	float minLifeTime;

	type pType;
	int numFireworksToInstantiate;

	int velMin;
	int velMax;

	type childType;

	physx::PxTransform pos = physx::PxTransform(0, 0, 0);
};

class FireworkSystem:public GeneradorSimple {
public:
	FireworkSystem(ParticleForceRegistry* fR, Vector3 posIni, Vector4 color);

	~FireworkSystem();

	void update(float t);
	virtual void generateParticles() { };
	void instantiateInitFirework();
	void instantiateFirework(type t, Vector3 parentPos = Vector3(0, 0, 0), Vector3 parentVel = Vector3(0, 0, 0));
	vector<typeInfo> info;

private:
	

	std::vector<RenderItem*> spheres;
	std::vector<int> sphereSizes;

	RenderItem* expSphere;

	std::vector<ParticleForceGenerator*> generators;
	ParticleForceRegistry* forceRegistry;
	list<Firework*> fireworks;

	std::list<ParticleExp>* particleExplosions;

	
	
	void createFirework(const typeInfo& type, Vector3 pos, Vector3 vel);
};


