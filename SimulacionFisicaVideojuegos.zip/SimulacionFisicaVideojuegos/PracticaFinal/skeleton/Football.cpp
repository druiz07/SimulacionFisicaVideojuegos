#include "Football.h"
#include <fstream>
#include <iostream>
#include <windows.h>




FootBallScene::FootBallScene(PxScene* scene, PxPhysics* physics) {
	gScene = scene;
	gPhysics = physics;

	srand(time(NULL));
}

void FootBallScene::initObjects() {
	camaraInicial = { -358.69, 289.019, 9.86761 };
	GetCamera()->setDir(physx::PxVec3(1, -0.3, 0));
	GetCamera()->setEye(camaraInicial);

	creacionCampo();
	creacionBola();
	//createSound();
	creaGente();
	creaFuegosArt();
	creaSistemaParticulas();
	creaSistemasSolidos();
	creacionObst();
	floteGradas();
}

void FootBallScene::update(float t) {
	fireworkSystemRoja->update(t);
	fireworkSystemAzul->update(t);

	registroElemsPublicos->updateForces(t);
	for (auto p : publico) p->update(t);

	compruebaGol();

	sistemaParticulas->update(t);
	forceRegistrySistema->updateForces(t);

	forceRegistryCajas->updateBodyForces(t);

	forceRegistryCajas->addBodyForce(bodySystemRoja->getBodies(), new BodyWind(Vector3(0, -50, 0)));
	forceRegistryCajas->addBodyForce(bodySystemAzul->getBodies(), new BodyWind(Vector3(0, -50, 0)));
	bodySystemRoja->update(t);
	bodySystemAzul->update(t);

	forceRegistryFlotacion->updateForces(t);
	for (auto a : pFlotantes) a->update(t);
}

void FootBallScene::keyPress(char k) {
	switch (k)
	{
	case 'T':
	{
		tiro();
		break;
	}
	case 'O' :
	{
		nAngCamera+=1;
		GetCamera()->orbit(nAngCamera);
		break;
	}
	case 'U':
	{
		std::cout << GetCamera()->getDir().x<<endl;
		std::cout << GetCamera()->getDir().z<<endl;
		break;
	}
	default:
		break;
	}
}

void FootBallScene::destroyObjects() {
	//Limpieza de los elementos de una escena
	DeregisterRenderItem(suelo);

	for (auto a : barreras) DeregisterRenderItem(a);
	for (auto a : gradas) {
		DeregisterRenderItem(a->rI); delete a->p;
	}
	for (auto a : porterias) {
		DeregisterRenderItem(a->rI); delete a->p;
	}
	for (auto p : publico) delete p;

	delete forceRegistrySistema;
	delete sistemaParticulas;
	delete registroElemsPublicos;
	delete pRojaRegistro;
	delete pAzulRegistro;


	delete porteriaRoja;
	delete porteriaAzul;
	delete fireworkSystemRoja;
	delete fireworkSystemAzul;


}

RenderItem* FootBallScene::createStaticBody(Vector3 position, PxReal sizeX, PxReal sizeY, PxReal sizeZ, Vector4 color) {
	PxShape* forma = CreateShape(PxBoxGeometry(sizeX, sizeY, sizeZ));
	PxRigidStatic* ground = gPhysics->createRigidStatic({ position.x, position.y, position.z });
	ground->attachShape(*forma);
	gScene->addActor(*ground);
	RenderItem* ri = new RenderItem(forma, ground, color);

	return ri;
}

Obj* FootBallScene::creaObjeto(Vector3 pos, PxReal sizeX, PxReal sizeY, PxReal sizeZ, Vector4 color) {
	PxTransform* px = new PxTransform(pos.x, pos.y, pos.z);

	Obj* o = new Obj({ new RenderItem(CreateShape(physx::PxBoxGeometry(sizeX, sizeY, sizeZ)), px, color), px });
	return o;
}

void FootBallScene::creacionCampo() {
	//Suelo
	suelo = createStaticBody({ 0,0,0 }, 625, 1, 425, { 0.5, 0.5, 0, 1 });


	//Porterias
	//Roja
	porterias.push_back(creaObjeto({ 700, 100, 0 }, 1, 200, 175, { 1, 0, 0, 1 }));
	porterias.push_back(creaObjeto({ 665, 100, 175 }, 38, 200, 1, { 1, 0, 0, 1 }));
	porterias.push_back(creaObjeto({ 665, 100, -175 }, 38, 200, 1, { 1, 0, 0, 1 }));

	porterias.push_back(creaObjeto({ 665, 0, 0 }, 38, 1, 175, { 1, 0, 0, 1 }));

	//Azul
	porterias.push_back(creaObjeto({ -700, 100, 0 }, 1, 200, 175, { 0, 1, 0, 1 }));
	porterias.push_back(creaObjeto({ -665, 100, 175 }, 38, 200, 1, { 0, 1, 0, 1 }));
	porterias.push_back(creaObjeto({ -665, 100, -175 }, 38, 200, 1, { 0, 1, 0, 1 }));
	porterias.push_back(creaObjeto({ -665, 0, 0 }, 38, 1, 175, { 0, 1, 0, 1 }));




	//Barreras
	barreras.push_back(createStaticBody({ 0, 30, -425 }, 625, 30, 1, { 0.1, 0.9, 0.6, 1 }));
	barreras.push_back(createStaticBody({ 0, 30, 425 }, 625, 30, 1, { 0.1, 0.9, 0.5, 1 }));
	barreras.push_back(createStaticBody({ -625, 30, 300 }, 1, 30, 125, { 0.1, 0.9, 0.8, 1 }));
	barreras.push_back(createStaticBody({ -625, 30, -300 }, 1, 30, 125, { 0.1, 0.9, 0.8, 1 }));
	barreras.push_back(createStaticBody({ 625, 30, 300 }, 1, 30, 125, { 0.1, 0.9, 0.4, 1 }));
	barreras.push_back(createStaticBody({ 625, 30, -300 }, 1, 30, 125, { 0.1, 0.9, 0.8, 1 }));



	//Trigger Roja
	porteriaRoja = creaObjeto({ 625, 100, 0 }, 1, 200, 175, { 1, 0, 0, 0 });

	//Trigger Azul
	porteriaAzul = creaObjeto({ -625, 100, 0 }, 1, 200, 175, { 0, 1, 0, 0 });

	int x = 1000; int z = 30; int w = 750;

	//Gradas
	gradas.push_back(creaObjeto({ 0, -1, 0 }, 1200, 1, 1000, { 0.35, 0.35, 0.5, 1 }));

	//1
	gradas.push_back(creaObjeto({ 0, 30, 550 }, x, z, 1, { 0.3, 0.7, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 60, 580 }, x, 1, z, { 0.3, 0.7, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 0, 90, 610 }, x, z, 1, { 0.3, 0.7, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 120, 640 }, x, 1, z, { 0.3, 0.7, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 0, 150, 670 }, x, z, 1, { 0.3, 0.7, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 180, 700 }, x, 1, z, { 0.3, 0.7, 0.6, 1 }));

	//2
	gradas.push_back(creaObjeto({ 0, 30, -550 }, x, z, 1, { 0.7, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 60, -580 }, x, 1, z, { 0.7, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 0, 90, -610 }, x, z, 1, { 0.7, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 120, -640 }, x, 1, z, { 0.7, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 0, 150, -670 }, x, z, 1, { 0.7, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 180, -700 }, x, 1, z, { 0.7, 0.2, 0.6, 1 }));

	//3
	gradas.push_back(creaObjeto({ -750, 30, 0 }, 1, z, w, { 0.6, 0.5, 0.2, 1 }));
	gradas.push_back(creaObjeto({ -780, 60, 0 }, z, 1, w, { 0.6, 0.5, 0.2, 1 }));

	gradas.push_back(creaObjeto({ -810, 90, 0 }, 1, z, w, { 0.6, 0.5, 0.2, 1 }));
	gradas.push_back(creaObjeto({ -840, 120, 0 }, z, 1, w, { 0.6, 0.5, 0.2, 1 }));

	gradas.push_back(creaObjeto({ -870, 150, 0 }, 1, z, w, { 0.6, 0.5, 0.2, 1 }));
	gradas.push_back(creaObjeto({ -900, 180, 0 }, z, 1, w, { 0.6, 0.5, 0.2, 1 }));

	//4
	gradas.push_back(creaObjeto({ 750, 30, 0 }, 1, z, w, { 0.1, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 780, 60, 0 }, z, 1, w, { 0.1, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 810, 90, 0 }, 1, z, w, { 0.1, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 840, 120, 0 }, z, 1, w, { 0.1, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 870, 150, 0 }, 1, z, w, { 0.1, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 900, 180, 0 }, z, 1, w, { 0.1, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 930, 90, 0 }, 1, 90, w, { 0.1, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ -930, 90, 0 }, 1, 90, w, { 0.1, 0.2, 0.6, 1 }));

	gradas.push_back(creaObjeto({ 0, 90, -730 }, x, 90, 1, { 0.1, 0.2, 0.6, 1 }));
	gradas.push_back(creaObjeto({ 0, 90, 730 }, x, 90, 1, { 0.1, 0.2, 0.6, 1 }));
}

void FootBallScene::creacionBola() {
	pelota = new SolidBody();
	pelota->rigid = gPhysics->createRigidDynamic(PxTransform(0, 30, 0));
	PxShape* shape = CreateShape(PxSphereGeometry(30));
	pelota->rigid->attachShape(*shape);

	pelota->rigid->setMass(10);
	pelota->rigid->setLinearDamping(1);

	pelota->rigid->setMassSpaceInertiaTensor(PxVec3(0, 0, 0));

	gScene->addActor(*pelota->rigid);
	pelota->isnew = true;
	pelota->life = INT_MAX;
	pelota->force = { 0.0, 0.0, 0.0 };
	pelota->torque = { 0.0, 0.0, 0.0 };
	pelota->item = new RenderItem(shape, pelota->rigid, { 0.502,0, 0.502,1 });

}

void FootBallScene::tiro() {
	auto camPos = GetCamera()->getEye();
	camPos.y = 30;
	auto forceFactor = 1000;
	auto dir = (pelota->rigid->getGlobalPose().p - camPos);
	
	dir = dir.getNormalized();

	pelota->rigid->setLinearVelocity(dir * forceFactor);
}

void FootBallScene::creaFuegosArt() {
	pRojaRegistro = new ParticleForceRegistry();
	pAzulRegistro = new ParticleForceRegistry();

	fireworkSystemRoja = new FireworkSystem(pRojaRegistro, { -665, 200, 0 }, { 0, 1, 0, 1 });
	fireworkSystemAzul = new FireworkSystem(pAzulRegistro, { 665, 200, 0 }, { 1, 0, 0, 1 });
}

void FootBallScene::creaGente() {
	registroElemsPublicos = new ParticleForceRegistry();

	for (int i = 0; i < 15; i++) {
		creaMuellesPersonas(Vector3(-700 + (i * 100), 140, 580), Vector3(-700 + (i * 100), 110, 580));
	}
	for (int i = 0; i < 17; i++) {
		creaMuellesPersonas(Vector3(-800 + (i * 100), 200, 640), Vector3(-800 + (i * 100), 170, 640));
	}
	for (int i = 0; i < 19; i++) {
		creaMuellesPersonas(Vector3(-900 + (i * 100), 260, 700), Vector3(-900 + (i * 100), 230, 700));
	}

	for (int i = 0; i < 15; i++) {
		creaMuellesPersonas(Vector3(-700 + (i * 100), 140, -580), Vector3(-700 + (i * 100), 110, -580));
	}
	for (int i = 0; i < 17; i++) {
		creaMuellesPersonas(Vector3(-800 + (i * 100), 200, -640), Vector3(-800 + (i * 100), 170, -640));
	}
	for (int i = 0; i < 19; i++) {
		creaMuellesPersonas(Vector3(-900 + (i * 100), 260, -700), Vector3(-900 + (i * 100), 230, -700));
	}


	for (int i = 0; i < 11; i++) {
		creaMuellesPersonas(Vector3(-775, 140, 500 - (i * 100)), Vector3(-775, 110, 500 - (i * 100)));
	}
	for (int i = 0; i < 13; i++) {
		creaMuellesPersonas(Vector3(-837, 200, 600 - (i * 100)), Vector3(-837, 170, 600 - (i * 100)));
	}
	for (int i = 0; i < 13; i++) {
		creaMuellesPersonas(Vector3(-900, 260, 600 - (i * 100)), Vector3(-900, 230, 600 - (i * 100)));
	}

	for (int i = 0; i < 11; i++) {
		creaMuellesPersonas(Vector3(775, 140, 500 - (i * 100)), Vector3(775, 110, 500 - (i * 100)));
	}
	for (int i = 0; i < 13; i++) {
		creaMuellesPersonas(Vector3(837, 200, 600 - (i * 100)), Vector3(837, 170, 600 - (i * 100)));
	}
	for (int i = 0; i < 13; i++) {
		creaMuellesPersonas(Vector3(900, 260, 600 - (i * 100)), Vector3(900, 230, 600 - (i * 100)));
	}

}

void FootBallScene::creaMuellesPersonas(Vector3 posMuelle, Vector3 posParticula) { //int size, Vector4 color, float restLenght

	float r = (rand() % 9 + 1); r /= 10;
	float g = (rand() % 9 + 1); g /= 10;
	float b = (rand() % 9 + 1); b /= 10;
	float size = rand() % 75 + 200; //Size

	float mass = 20;
	float restLenght = rand() % 10 + 45;

	float* k = new float(300);

	publico.push_back(new Particula(posParticula, Vector3(0, 0, 0), Vector3(0, 0, 0), { r, g, b, 1 }, INT_MAX, size, mass));

	//Esto es lo que crea el movimiento de la particula
	registroElemsPublicos->add(publico.at(publico.size() - 1), new ParticleAnchoredSpring(new Vector3(posMuelle.x, posMuelle.y, posMuelle.z), k, restLenght));
	//Para que no vayan subiendo hacia arriba 

   registroElemsPublicos->add(publico.at(publico.size() - 1), new ParticleDrag(0.01, 0.01));
}

void FootBallScene::compruebaGol() {
	if (PxGeometryQuery::overlap(pelota->item->shape->getGeometry().sphere(), pelota->rigid->getGlobalPose(), porteriaRoja->rI->shape->getGeometry().box(), *porteriaRoja->p)) {
		pelota->rigid->setGlobalPose(PxTransform(0, 30, 0));
		pelota->rigid->setLinearVelocity(Vector3(0, 0, 0));

		fireworkSystemRoja->instantiateInitFirework();

		bodySystemAzul->addBody();
		std::cout << "GOL PARA EQUIPO ROJO";
	}
	else if (PxGeometryQuery::overlap(pelota->item->shape->getGeometry().sphere(), pelota->rigid->getGlobalPose(), porteriaAzul->rI->shape->getGeometry().box(), *porteriaAzul->p)) {
		pelota->rigid->setGlobalPose(PxTransform(0, 30, 0));
		pelota->rigid->setLinearVelocity(Vector3(0, 0, 0));

		fireworkSystemAzul->instantiateInitFirework();

		bodySystemRoja->addBody();
		bodySystemAzul->addBody();
		std::cout << "GOL PARA EQUIPO VERDE";
	}
}


void FootBallScene::creaSistemaParticulas() {
	forceRegistrySistema = new ParticleForceRegistry();

	sistemaParticulas = new SistemaParticulas(0.4, 20, 120, 60, 100, forceRegistrySistema);
}

void FootBallScene::creaSistemasSolidos() {
	forceRegistryCajas = new ParticleForceRegistry();


	bodySystemRoja = new BodySystem(gScene, gPhysics, forceRegistryCajas, PxTransform(650, 450, 0), nullptr, 5.0F, false, 10.0F, 7.0F, 20, { 1, 0, 0, 1 });
	bodySystemAzul = new BodySystem(gScene, gPhysics, forceRegistryCajas, PxTransform(-650, 450, 0), nullptr, 5.0F, false, 10.0F, 7.0F, 20, { 0, 1, 0, 1 });
}

void FootBallScene::creacionObst() {
	obstaculos.push_back(createStaticBody(Vector3(-500, 30, -245), 1, 30, 185, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(-500, 30, 260), 1, 30, 170, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(-325, 30, 185), 1, 30, 245, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(-325, 30, -220), 1, 30, 50, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(-200, 30, -185), 1, 30, 230, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(-200, 30, 220), 1, 30, 50, { 0.3, 0.4, 0.5, 1 }));


	obstaculos.push_back(createStaticBody(Vector3(+500, 30, -245), 1, 30, 185, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(+500, 30, 260), 1, 30, 170, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(+325, 30, 185), 1, 30, 245, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(+325, 30, -220), 1, 30, 50, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(+200, 30, -185), 1, 30, 230, { 0.3, 0.4, 0.5, 1 }));
	obstaculos.push_back(createStaticBody(Vector3(+200, 30, 220), 1, 30, 50, { 0.3, 0.4, 0.5, 1 }));

}

void FootBallScene::floteGradas() {
	forceRegistryFlotacion = new ParticleForceRegistry();
	float depth = 2;
	float vol = 0.1;


	Particula* p2 = new Particula(Vector3(900, -50, -900), Vector3(0, 0, 0), Vector3(0, 0, 0), { 1, 0, 0, 1 }, INT_MAX, 100, 4);
	p2->setdepthVol(depth, vol);
	pFlotantes.push_back(p2);
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleGravity(Vector3(0, -9.8f, 0)));
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleBuoyancy(2));

	Particula* p3 = new Particula(Vector3(-900, -50, -900), Vector3(0, 0, 0), Vector3(0, 0, 0), { 1, 0, 0, 1 }, INT_MAX, 100, 4);
	p3->setdepthVol(depth, vol);
	pFlotantes.push_back(p3);
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleGravity(Vector3(0, -9.8f, 0)));
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleBuoyancy(2));

	Particula* p = new Particula(Vector3(900, -50, 900), Vector3(0, 0, 0), Vector3(0, 0, 0), { 1, 0, 0, 1 }, INT_MAX, 100, 4);
	p->setdepthVol(depth, vol);
	pFlotantes.push_back(p);
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleGravity(Vector3(0, -9.8f, 0)));
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleBuoyancy(2));

	Particula* p1 = new Particula(Vector3(-900, -50, 900), Vector3(0, 0, 0), Vector3(0, 0, 0), { 1, 0, 0, 1 }, INT_MAX, 100, 4);
	p1->setdepthVol(depth, vol);
	pFlotantes.push_back(p1);
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleGravity(Vector3(0, -9.8f, 0)));
	forceRegistryFlotacion->add(pFlotantes.at(pFlotantes.size() - 1), new ParticleBuoyancy(2));


}

