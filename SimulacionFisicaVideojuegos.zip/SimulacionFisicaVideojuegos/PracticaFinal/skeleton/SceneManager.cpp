#include "SceneManager.h"

SceneManager::SceneManager(Scene* s) {
	scene = s;
	scene->initObjects();
}

SceneManager::~SceneManager() {
	removeScene();
}

void SceneManager::loadScene(Scene* s) {
	if (scene != nullptr) removeScene();

	scene = s;
	scene->initObjects();
}

void SceneManager::removeScene() {
	scene->destroyObjects();
	delete scene;
}

Scene* SceneManager::getCurrentScene() {
	return scene;
}
