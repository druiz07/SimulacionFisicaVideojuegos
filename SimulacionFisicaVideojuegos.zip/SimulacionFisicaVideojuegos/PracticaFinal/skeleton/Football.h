#pragma once
#include <vector>
#include "Particula.h"
#include "Scene.h"
#include "SolidBody.h"
#include "FireworkSystem.h"
#include "SistemaParticulas.h"
#include "BodySystem.h"
#include "BodyWind.h"
#include "ParticleBuoyancy.h"
#include "ParticleForceRegistry.h"
#include "ParticleAnchoredSpring.h"
#include "RenderUtils.hpp"
#include "core.hpp"

#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

using namespace physx;

struct Obj {
	RenderItem* rI;
	PxTransform* p;
};

class FootBallScene : public Scene {
public:
	FootBallScene(PxScene* gScene, PxPhysics* gPhysics);
	void initObjects();
	void destroyObjects();
	void update(float t);
	void keyPress(char k);

private:
	PxScene* gScene;
	PxPhysics* gPhysics;

	SistemaParticulas* sistemaParticulas;
	ParticleForceRegistry* forceRegistrySistema;

	ParticleForceRegistry* pRojaRegistro;
	ParticleForceRegistry* pAzulRegistro;
	ParticleForceRegistry* registroElemsPublicos;

	RenderItem* suelo;

	std::vector<RenderItem*> barreras;
	std::vector<RenderItem*> obstaculos;
	std::vector<Obj*> gradas;
	std::vector<Obj*> porterias;

	//Objetos Porteria
	Obj* porteriaRoja;
	Obj* porteriaAzul;

	SolidBody* pelota;

	FireworkSystem* fireworkSystemRoja;
	FireworkSystem* fireworkSystemAzul;

	BodySystem* bodySystemRoja;
	BodySystem* bodySystemAzul;
	ParticleForceRegistry* forceRegistryCajas;

	std::vector<Particula*> publico;
	physx::PxVec3 camaraInicial;

	//Flotacion
	ParticleForceRegistry* forceRegistryFlotacion;
	vector<Particula*> pFlotantes;
	ParticleGravity* gravity = NULL;
	int nAngCamera=0;

	RenderItem* createStaticBody(Vector3 position, PxReal sizeX, PxReal sizeY, PxReal sizeZ, Vector4 color);
	Obj* creaObjeto(Vector3 pos, PxReal sizeX, PxReal sizeY, PxReal sizeZ, Vector4 color);
	void creacionCampo();
	void creacionBola();
	void creacionObst();
	void floteGradas();
	void tiro();
	void creaFuegosArt();
	void creaGente();
	void creaSistemaParticulas();
	void creaSistemasSolidos();
	void creaMuellesPersonas(Vector3 posMuelle, Vector3 posParticula);
	void compruebaGol();
};
