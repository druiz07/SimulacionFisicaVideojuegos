#pragma once
#include "Particula.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

#include <vector>
#include <list>
#include "ParticleGravity.h"
#include "ParticleForceRegistry.h"
#include "ParticleDrag.h"
#include "ParticleWind.h"
#include "ParticleExplosion.h"
#include "Torbellino.h"
#include "Explosion.h"
#include "GeneradorSimple.hpp"

using namespace std;

class SistemaParticulas {
public:
	SistemaParticulas(float c, int LT, int V, int nP, int size, ParticleForceRegistry* fR);

	~SistemaParticulas();

	void update(float t);

private:
	void instantiateParticles();

	float actTime;
	float cadence;
	int lifeTime;
	int speed;
	int size;
	int numParticulas;

	ParticleForceRegistry* forceRegistry;
	list<Particula*> particulas;
};

