Manual de usuario
Teclas “A”, “W”, “S”, “D -> movimiento de la cámara.

Tecla T en la dirección en la que este mirando la cámara -> Disparo a Portería ->
